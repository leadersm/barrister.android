package com.lsm.barrister.data.entity;

import java.io.Serializable;

/**
 * 学习中心频道
 */
public class Channel implements Serializable {
    public String id;//id
    public String title;//频道名称
}